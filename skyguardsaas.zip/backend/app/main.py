
from fastapi import FastAPI, UploadFile, File
import cv2
import numpy as np
import shutil
import os

app = FastAPI()

@app.post("/events/upload")
async def upload_event(file: UploadFile = File(...)):
    file_location = f"temp_{file.filename}"
    with open(file_location, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    cap = cv2.VideoCapture(file_location)
    motion_detected_frame = -1
    frame_id = 0
    ret, frame1 = cap.read()
    ret, frame2 = cap.read()

    while ret:
        diff = cv2.absdiff(frame1, frame2)
        gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        _, thresh = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)
        countours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        if len(countours) > 0:
            motion_detected_frame = frame_id
            break

        frame1 = frame2
        ret, frame2 = cap.read()
        frame_id += 1

    cap.release()
    os.remove(file_location)

    if motion_detected_frame >= 0:
        return {"status": "ok", "message": f"Movimento detectado no frame {motion_detected_frame}"}
    else:
        return {"status": "ok", "message": "Nenhum movimento detectado"}
