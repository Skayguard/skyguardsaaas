import React, { useState } from 'react';
import axios from 'axios';

export default function App() {
  const [video, setVideo] = useState(null);
  const [response, setResponse] = useState('');

  const handleUpload = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('file', video);

    try {
      const res = await axios.post('http://localhost:8000/events/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setResponse(res.data.message);
    } catch (error) {
      console.error(error);
      setResponse('Erro ao processar vídeo.');
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Skyguard SAAS</h1>
      <form onSubmit={handleUpload}>
        <input type="file" accept="video/*" onChange={(e) => setVideo(e.target.files[0])} />
        <button type="submit">Enviar Vídeo</button>
      </form>
      <p><strong>Resultado:</strong> {response}</p>
    </div>
  );
}
